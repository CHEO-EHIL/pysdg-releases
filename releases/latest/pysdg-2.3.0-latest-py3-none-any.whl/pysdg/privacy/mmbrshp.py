import pandas as pd
import numpy as np
import time
from functools import partial
from multiprocessing import Pool, cpu_count
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import KBinsDiscretizer
from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
import copy
from typing import Tuple



class MmbrshpRsk():
    
    def __init__(self, real_data: pd.DataFrame, population_size: int, h=10, seed=13, max_no_cores=None ):
        """Calculates the membership disclosure risk associated with synthetic data.
        
        Args:
            real_data (dataframe): Real Dataset as Pandas dataframe.
            population_size (int): The population size of from which the real dataset was sampled.
            h (int): An integer representing the hamming distance threshold to be used when calculating the membership disclosure risk.
            seed (int): An integer for fixing the seed to ensure reproducibility. Set to None if randomness is desired. 
            max_no_cores (str): Specifies the number of cores as either 'hi' for maximum number of cores, 'lo' for 5 cores or None for no multiprocessing.
            
        """
        
        assert isinstance(real_data, pd.DataFrame), "Input real data shall be Pandas datatframe"
        assert population_size > len(real_data), "Population size shall be larger than the provided real data"
        self.real_data=real_data
        self.population_size=population_size
        self.h=h
        self.quasiID=None #A list of the names of quais variables to be used in the calculation. If None, all variables will be used.
        self.max_no_cores=max_no_cores
        self.no_bins=20 #The number of bins to discretize continuous and high cardinality categorical variables. 
        self.seed=seed
        self.rng=np.random.default_rng(self.seed)
        self.train_data=self._partition()
        
    def _partition(self) -> pd.DataFrame:
        """ Partitions the REAL dataset into TRAINING and ATTACK datasets.

        Returns:
            train_data: Dataset to be used for training a generative model.
        
        """
        
        real_data=copy.deepcopy(self.real_data)
        #real_data['ID'] = range(len(real_data))    # add an id variable to real data
        t = len(real_data) / self.population_size
        idx_train, idx_attack=train_test_split(np.arange(len(real_data)),test_size=0.2-(t*0.2), train_size=0.8+(t*0.2), random_state=self.seed)        
        train_data_w_id = real_data.iloc[idx_train,:]
        attack_data_w_id = real_data.iloc[idx_attack,:]
        
        #Check if  train_data_w_id turns to include constant column, and if 'yes', then redo splitting using stratified splitting
        if (train_data_w_id == train_data_w_id.iloc[0]).all().any():
            poor_cols=list(real_data.columns[(train_data_w_id == train_data_w_id.iloc[0]).all()]) #columns that turn to be constant if split is made using train_tets_split method above
            train_data_w_id=real_data.groupby(poor_cols, group_keys=False).apply(lambda x: x.sample(frac=0.8+(t*0.2)))
            attack_data_w_id=real_data.drop(train_data_w_id.index, axis=0)
            
        attack_data_w_id = pd.concat([attack_data_w_id, train_data_w_id.sample(int(np.ceil(t*len(real_data)*0.2)), random_state=self.seed)], axis=0)
        print(f"Partitioning resulted in total number of Attack Records= {len(attack_data_w_id)}, and the number of Attack Records in the training datasset= {int(np.ceil(t*len(real_data)*0.2))}")
        #attack_data_w_id.reset_index(inplace=True, drop=True)
        #train_data_w_id.reset_index(inplace=True, drop=True)
        train_data=copy.deepcopy(train_data_w_id)
        train_data=train_data.sample(frac=1, random_state=self.seed).reset_index(drop=True)
        self._train_data_w_id=train_data_w_id #Training data with an additional column 'ID' for tracking purposes.
        self._attack_data_w_id=attack_data_w_id #Attack data with an additional column 'ID' for tracking purposes.
        self.t=t
        return train_data #Training data without ID
    
    def calc_risk(self,syn_data: pd.DataFrame) -> Tuple[float, float]:
        """ Calculates the membership disclosure risk. 
        
        Args:
            syn_data: Synthetic dataset (synth). 
            
        Returns:
            Relative F1 score for membership disclosure risk.
            Naive F1 score for membership disclosure risk.        
        """
        
        assert (self.real_data.columns == syn_data.columns).all(), "Real and Synthetic dataset should have the same variable names"
        assert (self.real_data.dtypes == syn_data.dtypes).all(), "Real and Synthetic dataset should have the same variable types"
        assert isinstance(self._train_data_w_id, pd.DataFrame) and isinstance(self._attack_data_w_id, pd.DataFrame), "You need to partition the real dataset before calculating the membership disclosure risk"
        
        assert self.h > 0
        if self.quasiID is None:
            self.quasiID = list(self.real_data.columns)
        
        # detect types of variables
        dataTypes=self._type_detector(self.real_data.loc[:,self.quasiID]) #Note: Ensure that the output data types dataframe does NOT include the ID column 
        
        #discretize data 
        syn_data_disrete=copy.deepcopy(syn_data)
        attack_data_w_id_discrete=copy.deepcopy(self._attack_data_w_id)
        
        #impute data with average 
        
        
        for k in dataTypes.loc[(dataTypes['Type'] == "Discrete") | (dataTypes['Type'] == "Continuous"), "Name"]:
            discretizer = KBinsDiscretizer(n_bins=self.no_bins, strategy='uniform', encode='ordinal')
            syn_data_disrete[k] = discretizer.fit_transform(syn_data_disrete[k].values.reshape(-1,1))
            attack_data_w_id_discrete[k] = discretizer.transform(attack_data_w_id_discrete[k].values.reshape(-1,1)) #ID column will be excluded from discretization 
        
        #Calculate Membership Disclosure Risk
        print("CALCULATE MEMBERSHIP DISCLOSURE RISK")
        sim_match = self._hamming_min_match(attack_data_w_id_discrete, syn_data_disrete, self.quasiID, max_n_cores=self.max_no_cores)      
        pp=np.nansum(sim_match["DIST"] <= self.h)
        tp=np.nansum(np.in1d(attack_data_w_id_discrete.index[sim_match['DIST']<=self.h], self._train_data_w_id.index)) #True positive means a match (i.e. the attacker finds a records which means a patient is identified as a member in the training dataset.)
        p=np.nansum(np.in1d(attack_data_w_id_discrete.index, self._train_data_w_id.index))
        precision = 0 if pp == 0 else tp / pp
        recall = tp / p
        f1_baseMh = 0 if (precision + recall) == 0 else (2 * precision * recall) / (precision + recall)
        fyard_baseMh = 2*self.t/(1+self.t) #naive_f1 #per Xi and theory
        fnorm_baseMh = (f1_baseMh - fyard_baseMh) / (1 - fyard_baseMh) #rel_f1
        #print(f"Relative F1={fnorm_baseMh} and Naive F1={fyard_baseMh}")
        return fnorm_baseMh, fyard_baseMh
    
    

    def _type_detector(self, dataTable: pd.DataFrame, IDCol = None) -> pd.DataFrame:
        """ Detects the type of each variable in the input table.
        
        Args:
            dataTable: Input dataframe that includes mixed types of variables as columns. 
            
        Returns:
            A dataframe listing the types of each input variable. The identified types are: IDColumn,  Binary (0 or 1), Factors (i.e. categorical with cardinality <=10), Continuous, BinaryFactor (e.g. M or F, 1 or 2..etc) and Discrete (any integer with cardinality > 10).
        
        """
        
        for x in dataTable.columns:
            if dataTable[x].dtype == 'object':
                dataTable[x] = pd.factorize(dataTable[x])[0]
                dataTable[x]=dataTable[x].astype('category') #added line by SMK for python code
        
        Fits = pd.DataFrame({'Column': range(1, len(dataTable.columns) + 1), 'Name': dataTable.columns, 'Type': 'Filler', 'NAPercent': np.nan})
        iterRange = range(len(dataTable.columns))
        
        if IDCol is not None:
            Fits.loc[Fits['Name'] == IDCol, 'Type'] = 'IDColumn'
            Fits.loc[Fits['Name'] == IDCol, 'NAPercent'] = sum(dataTable[IDCol].isna()) / len(dataTable)
            iterRange = Fits.loc[Fits['Name'] != IDCol].index     
             
        for ii in iterRange:
            Fits.loc[ii, 'NAPercent'] = sum(dataTable.iloc[:, ii].isna()) / len(dataTable)
            if (len(dataTable.iloc[:, ii].dropna().unique()) == len(dataTable)) & (dataTable.iloc[:, ii].dtype != 'float64'): #last condition added my SMK
                Fits.loc[ii, 'Type'] = 'IDColumn'
            elif len(dataTable.iloc[:, ii].dropna().unique()) == 1:
                Fits.loc[ii, 'Type'] = 'Constant'
            elif (dataTable.iloc[:, ii].dtype=='int64') & sum((dataTable.iloc[:, ii] == 0) | (dataTable.iloc[:, ii] == 1) & (~dataTable.iloc[:, ii].isna())) == len(dataTable.iloc[:, ii].dropna()): #added first condition by SMK
                Fits.loc[ii, 'Type'] = 'Binary'
            elif dataTable.iloc[:, ii].dtype == 'float64':
                if len(dataTable.iloc[:, ii].dropna().unique()) <= 10:
                    Fits.loc[ii, 'Type'] = 'Factors'
                else:
                    Fits.loc[ii, 'Type'] = 'Continuous'
            elif dataTable.iloc[:, ii].dtype.name == 'category':
                if len(dataTable.iloc[:, ii].dropna().unique()) == 2:
                    Fits.loc[ii, 'Type'] = 'BinaryFactor'
                else:
                    Fits.loc[ii, 'Type'] = 'Factors'
            elif dataTable.iloc[:, ii].dtype == 'int64':
                if sum((dataTable.iloc[:, ii] == 0) | (dataTable.iloc[:, ii] == 1) & (~dataTable.iloc[:, ii].isna())) == len(dataTable.iloc[:, ii].dropna()):
                    Fits.loc[ii, 'Type'] = 'Binary'
                elif len(dataTable.iloc[:, ii].dropna().unique()) == 2:
                    Fits.loc[ii, 'Type'] = 'BinaryFactor'
                elif len(dataTable.iloc[:, ii].dropna().unique()) <= 10:
                    Fits.loc[ii, 'Type'] = 'Factors'
                else:
                    Fits.loc[ii, 'Type'] = 'Discrete'
        return Fits


    def _which_min(self,vec: np.array) -> int:
        minima = np.where(vec == np.min(vec))[0] #the minma  is a vector in case there are more than one minima
        if len(minima) > 1:
            minima = self.rng.choice(minima, 1) 
        return minima[0]


    def _calc_hamm(self, i, a_data: pd.DataFrame, b_data: pd.DataFrame) -> list:
            #print(f'PID: {os.getpid()}')
            ham_match_i=np.sum(a_data.values[i,:] != b_data.values, axis=1) #ham_match_i is a vector with a length of b_data
            min_i=self._which_min(ham_match_i)
            return  [min_i, ham_match_i[min_i]]

        
    def _hamming_min_match(self, attack_data: pd.DataFrame, syn_data: pd.DataFrame, QIDSet: list, max_n_cores: int) -> pd.DataFrame:
        """ Calculates the hamming distance matching table. 
        
        """
        start=time.time()
        
        a_data = attack_data[QIDSet]
        b_data = syn_data[QIDSet]
        
        if max_n_cores==None:
            res=pd.DataFrame(columns=['b_ID','DIST'])
            for i in range(a_data.shape[0]):
                ham_match_i=np.sum(a_data.values[i,:] != b_data.values, axis=1) #ham_match_i is a vector with a length of b_data. Every variable in a_data row is comapred with corresponding variable in b_data. A mistach is recorded is TRUE (1), then the number of mistaches are summed accorss that row. So, the higher teh number the more teh mismatches
                min_i=self._which_min(ham_match_i) #acorss all rows of b_data, the record that has the minimum mismatches is recorded. 
                res.loc[len(res)]=[min_i, ham_match_i[min_i]]
            return res
        elif max_n_cores == np.inf:
            n_cores = cpu_count()
        elif max_n_cores <np.inf:
            n_cores = min(cpu_count(), max_n_cores)
        
        calc_hamm_i=partial(self._calc_hamm,a_data=a_data, b_data=b_data )
        with Pool(n_cores) as p:
            res_lst=p.map(calc_hamm_i,range(a_data.shape[0]))
        res=pd.DataFrame(res_lst)
        res.columns=['b_ID','DIST']
        return res
    


###################


def calc_mmbrshp_risk(synth: pd.DataFrame,real_train: pd.DataFrame,real_holdout: pd.DataFrame,population_size: int,m:int=None, quasiID: list = None ,h: int = 5, no_bins: int = 20) -> Tuple[float, float]:
    """Calculates the membership disclosure risk.

    Args:
        synth: The synthetic dataset generated by a generative model.
        real_train: The real dataset that  was sampled form the population and used in training a generative model.
        real_holdout: The holdout dataset that was sampled form the population but not used in training a generative model.
        population_size: The population size.
        quasiID: The quasi variables of interest. All variables are used by default.
        h: An integer representing the hamming distance threshold used in calculation.
        no_bins: Number of bins used to discretize continuous and high cardinality discrete variables. 

    Returns:
        Relative F1 score for membership disclosure risk.
        Naive F1 score for membership disclosure risk.
    """
    
    def _check_subset_and_flag(A: pd.DataFrame, B: pd.DataFrame, subset_columns: list=None) -> pd.DataFrame:
        A2=A.copy()
        if subset_columns is None:
            subset_columns=list(A.columns)
        # Check if the rows of A exist in B based on the specified columns
        found_in_B= A[subset_columns].apply(lambda row: (B[subset_columns] == row).all(axis=1).any(), axis=1 )
        A2.loc[:,["found"]]=found_in_B
        return A2


    def _type_detector(dataTable: pd.DataFrame, IDCol=None) -> pd.DataFrame:
        for x in dataTable.columns:
            if dataTable[x].dtype == "object":
                dataTable[x] = pd.factorize(dataTable[x])[0]
                dataTable[x] = dataTable[x].astype(
                    "category"
                )  
        Fits = pd.DataFrame(
            {
                "Column": range(1, len(dataTable.columns) + 1),
                "Name": dataTable.columns,
                "Type": "Filler",
                "NAPercent": np.nan,
            }
        )
        iterRange = range(len(dataTable.columns))

        if IDCol is not None:
            Fits.loc[Fits["Name"] == IDCol, "Type"] = "IDColumn"
            Fits.loc[Fits["Name"] == IDCol, "NAPercent"] = sum(
                dataTable[IDCol].isna()
            ) / len(dataTable)
            iterRange = Fits.loc[Fits["Name"] != IDCol].index

        for ii in iterRange:
            Fits.loc[ii, "NAPercent"] = sum(dataTable.iloc[:, ii].isna()) / len(dataTable)
            if (len(dataTable.iloc[:, ii].dropna().unique()) == len(dataTable)) & (
                dataTable.iloc[:, ii].dtype != "float64"
            ):  # last condition added my SMK
                Fits.loc[ii, "Type"] = "IDColumn"
            elif len(dataTable.iloc[:, ii].dropna().unique()) == 1:
                Fits.loc[ii, "Type"] = "Constant"
            elif (dataTable.iloc[:, ii].dtype == "int64") & sum(
                (dataTable.iloc[:, ii] == 0)
                | (dataTable.iloc[:, ii] == 1) & (~dataTable.iloc[:, ii].isna())
            ) == len(
                dataTable.iloc[:, ii].dropna()
            ):  # added first condition by SMK
                Fits.loc[ii, "Type"] = "Binary"
            elif dataTable.iloc[:, ii].dtype == "float64":
                if len(dataTable.iloc[:, ii].dropna().unique()) <= 10:
                    Fits.loc[ii, "Type"] = "Factors"
                else:
                    Fits.loc[ii, "Type"] = "Continuous"
            elif dataTable.iloc[:, ii].dtype.name == "category":
                if len(dataTable.iloc[:, ii].dropna().unique()) == 2:
                    Fits.loc[ii, "Type"] = "BinaryFactor"
                else:
                    Fits.loc[ii, "Type"] = "Factors"
            elif dataTable.iloc[:, ii].dtype == "int64":
                if sum(
                    (dataTable.iloc[:, ii] == 0)
                    | (dataTable.iloc[:, ii] == 1) & (~dataTable.iloc[:, ii].isna())
                ) == len(dataTable.iloc[:, ii].dropna()):
                    Fits.loc[ii, "Type"] = "Binary"
                elif len(dataTable.iloc[:, ii].dropna().unique()) == 2:
                    Fits.loc[ii, "Type"] = "BinaryFactor"
                elif len(dataTable.iloc[:, ii].dropna().unique()) <= 10:
                    Fits.loc[ii, "Type"] = "Factors"
                else:
                    Fits.loc[ii, "Type"] = "Discrete"
        return Fits


    def _which_min(vec: np.array) -> int:
        rng = np.random.default_rng()
        minima = np.where(vec == np.min(vec))[0]  # the minma  is a vector in case there are more than one minima
        if len(minima) > 1:
            minima = rng.choice(minima, 1)
        return minima[0]


    def _hamming_min_match(attack_data: pd.DataFrame, syn_data: pd.DataFrame, QIDSet: list) -> pd.DataFrame:
        """Calculates the hamming distance matching table."""

        a_data = attack_data[QIDSet]
        b_data = syn_data[QIDSet]

        res = pd.DataFrame(columns=["b_ID", "DIST"])
        for i in range(a_data.shape[0]):
            ham_match_i = np.sum(a_data.values[i, :] != b_data.values, axis=1)  # ham_match_i is a vector with a length of b_data. Every variable in a_data row is comapred with corresponding variable in b_data. A mistach is recorded is TRUE (1), then the number of mistaches are summed accorss that row. So, the higher teh number the more teh mismatches
            min_i = _which_min(ham_match_i)  # acorss all rows of b_data, the record that has the minimum mismatches is recorded.
            res.loc[len(res)] = [min_i, ham_match_i[min_i]]
        return res

    if quasiID is None:
        quasiID = list(real_train.columns)

    t = len(real_train) / population_size
    
    if m is None:
        m=len(real_train)
    elif m>len(real_train):
        raise ValueError("Can not construct and attack dataset larger than the training dataset")

    # construct the attack dataset
    from_train=real_train.sample(int(m*t), random_state=13)
    from_holdout=real_holdout.sample(m-len(from_train), random_state=13)
    attack=pd.concat([from_train,from_holdout], axis=0, ignore_index=True)

    # detect types of variables
    dataTypes = _type_detector(real_train.loc[:, quasiID])  # Note: Ensure that the output data types dataframe does NOT include the ID column

    # discretize data
    synth_binned = copy.deepcopy(synth)
    attack_binned = copy.deepcopy(attack)
    real_train_binned = copy.deepcopy(real_train)

    cnt_dscrt_cols_w_na=dataTypes[(dataTypes['Type'].isin(['Continuous', 'Discrete'])) & (dataTypes['NAPercent'] > 0)]

    for row in cnt_dscrt_cols_w_na.itertuples():
        if row.Type=='Continuous':
            imp = SimpleImputer(missing_values=pd.NA, strategy="mean")

        elif row.Type=='Discrete':
            imp = SimpleImputer(missing_values=pd.NA, strategy="most_frequent")
        
        synth_binned.loc[:,row.Name] = imp.fit_transform(synth_binned[row.Name].values.reshape(-1, 1))  
        attack_binned.loc[:,row.Name] = imp.fit_transform(attack_binned[row.Name].values.reshape(-1, 1))  
        real_train_binned.loc[:,row.Name] = imp.fit_transform(real_train_binned[row.Name].values.reshape(-1, 1))   
        discretizer = KBinsDiscretizer(n_bins=no_bins, strategy="uniform", encode="ordinal")
        synth_binned.loc[:,row.Name] = discretizer.fit_transform(synth_binned[row.Name].values.reshape(-1, 1))
        attack_binned.loc[:,row.Name] = discretizer.transform(attack_binned[row.Name].values.reshape(-1, 1))  # ID column will be excluded from discretization
        real_train_binned.loc[:,row.Name] = discretizer.transform(real_train_binned[row.Name].values.reshape(-1, 1))  # ID column will be excluded from discretization

        
    # Calculate Membership Disclosure Risk
    print("Calculating membership disclosure risk")
    sim_match = _hamming_min_match(attack_binned, synth_binned, quasiID)
    pp = np.nansum(sim_match["DIST"] <= h)
    
    attack_binned_w_match_found=_check_subset_and_flag(attack_binned[sim_match["DIST"] <= h],real_train_binned )
    tp= sum(attack_binned_w_match_found['found']) # True positive means a match (i.e. the attacker finds a records which means a patient is identified as a member in the training dataset.)
    attack_binned_found=_check_subset_and_flag(attack_binned,real_train_binned)
    p=sum(attack_binned_found['found'])
    
    precision = 0 if pp == 0 else tp / pp
    recall = tp / p
    f1_baseMh = (0 if (precision + recall) == 0 else (2 * precision * recall) / (precision + recall))
    fyard_baseMh = 2 * t / (1 + t)  # naive_f1 #per Xi and theory
    fnorm_baseMh = (f1_baseMh - fyard_baseMh) / (1 - fyard_baseMh)  # rel_f1
    
    return fnorm_baseMh, fyard_baseMh