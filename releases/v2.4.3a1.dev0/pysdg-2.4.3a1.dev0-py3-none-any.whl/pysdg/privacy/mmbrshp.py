import pandas as pd
import numpy as np
import time
from functools import partial
from multiprocessing import Pool, cpu_count
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import KBinsDiscretizer
from typing import Tuple, Union





def _type_detector(dataTable: pd.DataFrame, IDCol=None) -> pd.DataFrame:
    for x in dataTable.columns:
        if dataTable[x].dtype == "object":
            dataTable[x] = pd.factorize(dataTable[x])[0]
            dataTable[x] = dataTable[x].astype("category")
    Fits = pd.DataFrame(
        {
            "Column": range(1, len(dataTable.columns) + 1),
            "Name": dataTable.columns,
            "Type": "Filler",
            "NAPercent": np.nan,
        }
    )
    iterRange = range(len(dataTable.columns))

    if IDCol is not None:
        Fits.loc[Fits["Name"] == IDCol, "Type"] = "IDColumn"
        Fits.loc[Fits["Name"] == IDCol, "NAPercent"] = sum(
            dataTable[IDCol].isna()
        ) / len(dataTable)
        iterRange = Fits.loc[Fits["Name"] != IDCol].index

    for ii in iterRange:
        Fits.loc[ii, "NAPercent"] = sum(dataTable.iloc[:, ii].isna()) / len(dataTable)
        if (len(dataTable.iloc[:, ii].dropna().unique()) == len(dataTable)) & (
            dataTable.iloc[:, ii].dtype != "float64"
        ):  # last condition added my SMK
            Fits.loc[ii, "Type"] = "IDColumn"
        elif len(dataTable.iloc[:, ii].dropna().unique()) == 1:
            Fits.loc[ii, "Type"] = "Constant"
        elif (dataTable.iloc[:, ii].dtype == "int64") & sum(
            (dataTable.iloc[:, ii] == 0)
            | (dataTable.iloc[:, ii] == 1) & (~dataTable.iloc[:, ii].isna())
        ) == len(
            dataTable.iloc[:, ii].dropna()
        ):  # added first condition by SMK
            Fits.loc[ii, "Type"] = "Binary"
        elif dataTable.iloc[:, ii].dtype == "float64":
            if len(dataTable.iloc[:, ii].dropna().unique()) <= 10:
                Fits.loc[ii, "Type"] = "Factors"
            else:
                Fits.loc[ii, "Type"] = "Continuous"
        elif dataTable.iloc[:, ii].dtype.name == "category":
            if len(dataTable.iloc[:, ii].dropna().unique()) == 2:
                Fits.loc[ii, "Type"] = "BinaryFactor"
            else:
                Fits.loc[ii, "Type"] = "Factors"
        elif dataTable.iloc[:, ii].dtype == "int64":
            if sum(
                (dataTable.iloc[:, ii] == 0)
                | (dataTable.iloc[:, ii] == 1) & (~dataTable.iloc[:, ii].isna())
            ) == len(dataTable.iloc[:, ii].dropna()):
                Fits.loc[ii, "Type"] = "Binary"
            elif len(dataTable.iloc[:, ii].dropna().unique()) == 2:
                Fits.loc[ii, "Type"] = "BinaryFactor"
            elif len(dataTable.iloc[:, ii].dropna().unique()) <= 10:
                Fits.loc[ii, "Type"] = "Factors"
            else:
                Fits.loc[ii, "Type"] = "Discrete"
    return Fits



def _calc_hamm(i, attack_data_quasi: pd.DataFrame, syn_data_quasi: pd.DataFrame) -> list:
    ham_match_i = np.sum(attack_data_quasi.values[i, :] != syn_data_quasi.values, axis=1 )  # ham_match_i is a vector with a length of syn_data_quasi. Every variable in attack_data_quasi row is compared with corresponding variable in syn_data_quasi. A mismatch is recorded is TRUE (1), then the number of mismatches are summed across that row. So, the higher the number the more the mismatches
    return np.min(ham_match_i)


def _hamming_min_match(
    attack_data: pd.DataFrame,
    syn_data: pd.DataFrame,
    quasi_vars: list,
    num_cores: int = None,
    logger=None,
) -> list:
    """Calculates the hamming distance matching table."""

    attack_data_quasi = attack_data[quasi_vars]
    syn_data_quasi = syn_data[quasi_vars]
    if num_cores == None:
        res_lst=[]
        for i in range(attack_data_quasi.shape[0]):
            res_i = _calc_hamm(i, attack_data_quasi=attack_data_quasi, syn_data_quasi=syn_data_quasi)
            res_lst.append(res_i)
        if logger:
            logger.info(
                "No multiprocessing is used for calculating the hamming distance matching table"
            )
        return np.array(res_lst)

    elif num_cores == -1:  # If -1 , then use all the available cores
        n_cores = cpu_count()
    elif num_cores > 0:
        n_cores = int(min(cpu_count(), num_cores))
    else:
        if logger:
            logger.error(
                "The number of cores should be a positive integer, -1  or None"
            )
        raise ValueError(
            "The number of cores should be a positive integer, -1  or None"
        )

    calc_hamm_i = partial(_calc_hamm, attack_data_quasi=attack_data_quasi, syn_data_quasi=syn_data_quasi)
    with Pool(n_cores) as p:
        res_lst = p.map(calc_hamm_i, range(attack_data_quasi.shape[0]))
    if logger:
        logger.info(
            f"Number of cores used in calculating hamming distance matching table = {n_cores}"
        )
    return np.array(res_lst)


def calc_mmbrshp_risk(
    synth_data: pd.DataFrame,
    training_data: pd.DataFrame,
    holdout_data: pd.DataFrame,
    population_size: int,
    attack_size: int = None,
    quasi_vars: list = None,
    hamming_threshold: int = 5,
    num_bins: int = 20,
    num_cores: int = None,
    logger=None,
    seed=None,
    raw_info: Union[str, dict]=None,
) -> Tuple[float, float]:
    """Calculates the membership disclosure risk.

    Args:
        synth_data (pd.DataFrame): The synthetic dataset generated by the relevant generative model.
        training_data (pd.DataFrame): The real dataset that was sampled from the population and used in training the generative model.
        holdout_data (pd.DataFrame): The holdout dataset that was sampled from the population but not used in training the generative model.
        population_size (int): The population size as an integer.
        attack_size (int, optional): The number of records in the attack dataset. If None, it is set to the size of the training dataset.
        quasi_vars (list, optional): A list of variable names that are used as quasi identifiers. All variables are used by default.
        hamming_threshold (int): An integer representing the hamming distance threshold used in calculation.
        num_bins (int): Number of bins used to discretize continuous and high cardinality discrete variables.
        num_cores (int or None): The number of cores to be used in the calculation.
            - Positive integer: Use that many cores.
            - -1: Use all available cores.
            - None: Disable multiprocessing.
        logger (optional): A logger object to log the progress of the calculation.
        seed (int, optional): An integer to set the seed for reproducibility.
        raw_info (str or dict):
            - If a string, it should be the full path to the json file describing the real data including its extension.
            - If a dictionary, it should be the dictionary describing the real data.


    Returns:
        dict: A dictionary containing the following keys: 
            t: The ratio of the training dataset size to the population size.
            f1: The F1 score.
            f_naive: The naive F1 score.
            f_rel: The relative F1 score.
            precision: The precision.
            recall: The recall.
            num_members: The number of training members in the attack dataset.
            num_non_members: The number of holdout members in the attack dataset.
            tp: The number of true positives.
            fp: The number of false positives.
            fn: The number of false negatives.
    """

    if raw_info is not None:
        from pysdg.synth.generate import Generator
        sgen=Generator()
        _=sgen.load(synth_data, raw_info)
        synth_data=sgen.enc_real.copy()
        tgen=Generator()
        _=tgen.load(training_data, raw_info)
        training_data=tgen.enc_real.copy()
        hgen=Generator()
        _=hgen.load(holdout_data, raw_info)
        holdout_data=hgen.enc_real.copy()
        training_data = training_data.loc[:, ~training_data.columns.str.contains('_missing')]
        synth_data = synth_data.loc[:, ~synth_data.columns.str.contains('_missing')]
        holdout_data = holdout_data.loc[:, ~holdout_data.columns.str.contains('_missing')]
        # Ensure all dataframes have the same columns
        common_columns = training_data.columns.intersection(synth_data.columns).intersection(holdout_data.columns)
        training_data = training_data[common_columns]
        synth_data = synth_data[common_columns]
        holdout_data = holdout_data[common_columns]

    if quasi_vars is None:
        quasi_vars = list(training_data.columns)
    
    if len(quasi_vars) <= 1:
        raise ValueError("The number of quasi-identifiers must be greater than 1.")

    t = len(training_data) / population_size

    if attack_size is None:
        attack_size = len(training_data)
    elif attack_size > len(training_data):
        raise ValueError(
            "Can not construct an attack dataset which is larger than the training dataset"
        )

    # construct the attack dataset
    if seed is not None and not isinstance(seed, int):
        raise ValueError("Seed must be an integer or None")
    if seed is not None:
        members = training_data.sample(int(attack_size * t), replace=False, random_state=seed)[quasi_vars].copy()
        non_members = holdout_data.sample(attack_size - len(members), replace=False, random_state=seed)[quasi_vars].copy()
    else:
        members = training_data.sample(int(attack_size * t), replace=False)[quasi_vars].copy()
        non_members = holdout_data.sample(attack_size - len(members), replace=False)[quasi_vars].copy()
    members['origin']="M"
    non_members['origin']="NM"
    attack_data_labeled = pd.concat([members, non_members], axis=0, ignore_index=True)
    # attack.to_csv("/share/team/data-synthesis/pysdg/test_data/enc_attack.csv", index=False)

    # detect types of variables
    dataTypes = _type_detector(
        training_data.loc[:, quasi_vars]
    )  # Note: Ensure that the output data types dataframe does NOT include the ID column

    # discretize data
    syn_data_discr_labeled = synth_data[quasi_vars].copy()
    syn_data_discr_labeled['origin'] = 'S'
    attack_data_discr_labeled = attack_data_labeled.copy()
    training_data_discr_labeled = training_data[quasi_vars].copy()
    training_data_discr_labeled['origin'] = 'T'

    cnt_dscrt_cols_w_na = dataTypes[
        (dataTypes["Type"].isin(["Continuous", "Discrete"]))
        & (dataTypes["NAPercent"] > 0)
    ]

    for row in cnt_dscrt_cols_w_na.itertuples():
        if row.Type == "Continuous":
            imp = SimpleImputer(missing_values=pd.NA, strategy="mean")

        elif row.Type == "Discrete":
            imp = SimpleImputer(missing_values=pd.NA, strategy="most_frequent")

        syn_data_discr_labeled.loc[:, row.Name] = imp.fit_transform(
            syn_data_discr_labeled[row.Name].values.reshape(-1, 1)
        )
        attack_data_discr_labeled.loc[:, row.Name] = imp.fit_transform(
            attack_data_discr_labeled[row.Name].values.reshape(-1, 1)
        )
        training_data_discr_labeled.loc[:, row.Name] = imp.fit_transform(
            training_data_discr_labeled[row.Name].values.reshape(-1, 1)
        )
        discretizer = KBinsDiscretizer(
            n_bins=num_bins, strategy="uniform", encode="ordinal"
        )
        syn_data_discr_labeled.loc[:, row.Name] = discretizer.fit_transform(
            syn_data_discr_labeled[row.Name].values.reshape(-1, 1)
        )
        attack_data_discr_labeled.loc[:, row.Name] = discretizer.transform(
            attack_data_discr_labeled[row.Name].values.reshape(-1, 1)
        )  # ID column will be excluded from discretization
        training_data_discr_labeled.loc[:, row.Name] = discretizer.transform(
            training_data_discr_labeled[row.Name].values.reshape(-1, 1)
        )  # ID column will be excluded from discretization


    # Calculate Membership Disclosure Risk
    print("Calculating membership disclosure risk")
    min_hamming_vec = _hamming_min_match(attack_data_discr_labeled, syn_data_discr_labeled, quasi_vars, num_cores=num_cores, logger=logger)
    hamming_mask=min_hamming_vec <= hamming_threshold

    matched_targets = attack_data_discr_labeled[hamming_mask]
    non_matched_targets = attack_data_discr_labeled[~hamming_mask]

    tp = sum(matched_targets['origin'] == "M")
    fp = sum(matched_targets['origin'] == "NM")
    fn = sum(non_matched_targets['origin'] == "M")

    precision = 0 if tp + fp == 0 else tp / (tp + fp)
    recall = 0 if tp + fn == 0 else tp / (tp + fn)
    f1 = 0 if precision + recall == 0 else 2 * (precision * recall) / (precision + recall)

    f_naive=2*t/(1+t)
    f_rel=(f1-f_naive)/(1-f_naive)

    labeled_res_dic = {
        "t": t,
        "f1": f1,
        "f_naive": f_naive,
        "f_rel": f_rel,
        "precision": precision,
        "recall": recall,
        "num_members": len(members),
        "num_non_members": len(non_members),
        "tp": tp,
        "fp": fp,
        "fn": fn,
    }

    return labeled_res_dic


