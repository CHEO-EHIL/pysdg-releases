import pandas as pd
import numpy as np
import os
import shutil
import copy
import time
import json
import dotenv
import tempfile
import json
import uuid

try:
    from ra_synthesis_sdk.synthesis_client import SynthesisClient
    from ra_synthesis_sdk.model.job import UtilityActionType
    from ra_synthesis_sdk.model.utility_assessment import UtilityAssessment
    from ra_synthesis_sdk.model.simulator_meta_info import SimulatorMetaInfo, SimulatorState
    replica_exist=True
except ImportError:
    replica_exist=False
    print("Warning: Replica generator library is not installed.")


def connect_replica() -> object:  # returns replica client object
    # read credentials
    dotenv.load_dotenv()
    # get KeyCLoak info from your admin
    DEFINED_CLIENT_ID = os.getenv('REPLICA_ID')
    DEFINED_CLIENT_SECRET = os.getenv('REPLICA_PWD')
    # HTTP APIs access example
    # private IP of Synthesis Core VM - get it from AWS Console or GCP console
    BASE_HOST = os.getenv('REPLICA_HOST')
    BASE_PORT = os.getenv('REPLICA_PORT')
    client = SynthesisClient(host=BASE_HOST, port=BASE_PORT)
    client.timeout_seconds = 360000
    client.set_credentials(client_id=DEFINED_CLIENT_ID,
                           client_secret=DEFINED_CLIENT_SECRET)
    client.login(with_scopes=client.USER_SCOPES)
    return client


def get_replica_risk(syn_df: pd.DataFrame, real_df: pd.DataFrame,  quasi_vars: list, population_size: int, sweep_replica_jobs: bool = True) -> float:
    '''Calculate the attribution disclosure risk. The attribution disclosure is calculated using Replica implementation so ensure to have access to the package.

    Args:
        syn_df: The synthetic dataset (i.e. synth).
        real_df: The real dataset
        quasi_vars: A list of the quasi identifier names. 
        population_size: The population size.

    Returns:
        Attribution disclosure risk.
    '''

    if not replica_exist:
        raise ImportError("Replica generator library is not installed. Please install it.")
    
    client = connect_replica()
    print(f"CALCULATE REPLICA RISK")
    plan = make_plan(real_df, quasi_vars, population_size)
    risk_res, job_id = calc_replica_risks(client, plan, real_df, syn_df)
    if sweep_replica_jobs:
        client.delete_privacy_job(job_id)
    
    return risk_res['membership_risk']


def make_plan(ds: pd.DataFrame, quasi_vars: list, population_size: int) -> dict:
    plan_dic = {
        "population_count": population_size,
        "name": f"Assurance test plan",
    }
    plan_dic['quasi_variables'] = quasi_vars
    plan_dic["real_sample_match_link_column"] = "real_sample_link"
    plan_dic["acceptable_risk_threshold"] = 0.09
    plan_dic["sensitive_variable_match_threshold"] = 0.05
    plan_dic["generalizations"] = []
    return plan_dic


def calc_replica_risks(client, plan, real_df, syn_df):
    temp_real_df = copy.deepcopy(real_df)
    temp_syn_df = copy.deepcopy(syn_df)
    # print(f"R debug out: plan = {plan}")
    for var in plan['quasi_variables']:
        # print(f"R debug out: quasi variable = {var}")
        if temp_real_df[var].dtype == 'float':
            temp_real_df.loc[:, var] = temp_real_df[var].round(0)
            temp_syn_df.loc[:, var] = temp_syn_df[var].round(0)
    with tempfile.TemporaryDirectory(dir=os.getcwd()) as temp_folder:
        unique_id = f'{os.getpid()}_{uuid.uuid4().hex}'
        temp_real_path = os.path.join(
            temp_folder, f'temp_real_{unique_id}.csv')
        temp_syn_path = os.path.join(temp_folder, f'temp_syn_{unique_id}.csv')
        temp_real_df.to_csv(temp_real_path, index=False)
        temp_syn_df.to_csv(temp_syn_path, index=False)
        plan_path = os.path.join(temp_folder, f"temp_plan_{unique_id}.json")
        with open(plan_path, 'w') as fp:
            json.dump(plan, fp)

        t1 = time.time()
        privacy_job = client.evaluate_privacy_on_input_data(
            plan_path, temp_real_path, temp_syn_path, pop_data_path=None, return_on_completion=False)
        privacy_job = client.get_privacy_job(privacy_job.job_id)
        print(privacy_job)
        client._wait_for_privacy_completion(privacy_job.job_id)
        t2 = time.time()

        print(f"evaluate privacy on input data  took", t2-t1, "seconds")
        json_path = client.download_privacy_json_report(
            privacy_job.job_id, temp_folder)
        risk_dic = _find_highest_risk_in_json_report(json_path)
    return risk_dic, privacy_job.job_id


def _find_highest_risk_in_json_report(report_file_path) -> dict:
    with open(report_file_path, 'r') as f:
        res = json.load(f)
    gen_node_reports = res["processing_report"]['gen_node_reports']
    all_risks = {
        "population_risk": [],
        "sample_risk": [],
        "membership_risk": [],
        "lambda_mid": [],
        "max_adjusted_risk": [],
        "n2": []
    }
    for gen_node_report in gen_node_reports:
        all_risks['population_risk'].append(gen_node_report['population_risk'])
        all_risks['sample_risk'].append(gen_node_report['sample_risk'])
        all_risks['membership_risk'].append(gen_node_report['membership_risk'])
        all_risks['lambda_mid'].append(gen_node_report['lambda_mid'])
        all_risks['max_adjusted_risk'].append(
            gen_node_report['max_adjusted_risk'])
        all_risks['n2'].append(gen_node_report['n2'])
    risk_dic = {
        "risk_threshold_applied": 0.09,
        "population_risk": max(all_risks['population_risk']),
        "sample_risk": max(all_risks['sample_risk']),
        "membership_risk": max(all_risks['membership_risk']),
        "lambda_mid": max(filter(None, all_risks['lambda_mid'])),
        "max_adjusted_risk": max(filter(None, all_risks['max_adjusted_risk'])),
        "n2": max(all_risks['n2'])
    }
    return risk_dic
