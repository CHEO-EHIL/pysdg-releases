import optuna 
import logging 
import sys

from functools import partial
from pysdg.synth.generate import Generator


class BayesianOptimizationRoutine:
    """A class for Bayesian optimization of synthetic data generation.

    Args:
        gen: The pysdg generator object created for "synthcity_ctgan".
        eval_function: A callable function to evaluate the generator.
        objective: The optimization objective, either "maximize" or "minimize". Default is "maximize".
        n_trials: The number of optimization trials. Default is 10.
        study_name: The name of the study. Default is "my_study".
        dump_sqlite: Whether to dump the study results to an SQLite database. Default is False. If True, the SQLite database will be saved as "study_name.db".
        dump_csv: Whether to dump the study results to a CSV file. Default is False. Enter the file path to dump the results.
    """

    def __init__(self, 
                 gen: Generator, 
                 eval_function: callable, 
                 objective: str = "maximize", 
                 n_trials: int = 10,
                 study_name: str = "my_study",
                 dump_sqlite: bool = False,
                 dump_csv: bool = False,
                 ):

        optuna.logging.get_logger("optuna").addHandler(logging.StreamHandler(sys.stdout))
        self.gen = gen
        self.eval_function = eval_function
        self.objective = objective
        self.n_trials = n_trials
        self.study_name = study_name
        self.dump_sqlite = dump_sqlite
        self.dump_csv = dump_csv

        self.supported_generators = ["synthcity_ctgan"]
        self.gen_name = gen.gen_name

        self.storage_name = f"sqlite:///{self.study_name}.db" if self.dump_sqlite else None
        self.study = optuna.create_study(direction=self.objective, storage=self.storage_name) 

        match self.gen_name:
            case "synthcity_ctgan":
                self.black_box_function = partial(self.ctgan_black_box_function, gen=self.gen)
            case _:
                raise ValueError(f"Generator support not available for {self.gen_name}. Supported generators are {self.supported_generators}")
        
        self.study.optimize(self.black_box_function, n_trials=self.n_trials)

        # Train the generator with the best parameters
        self.gen.synthcity_params = self.study.best_params
        self.gen.train()

        if self.dump_csv:
            self.study.trials_dataframe().to_csv(self.dump_csv, index=False)
    
    def get_optimization_results(self):
        """Returns the optimization results as a DataFrame."""
        return self.study.trials_dataframe()
    
    def ctgan_black_box_function(self, trial, gen):
        """Defines the black-box function for CTGAN optimization.

        Args:
            trial: An Optuna trial object.
            gen: The generator instance.

        Returns:
            The evaluation metric for the trial.
        """
        params = {
            "generator_n_layers_hidden": trial.suggest_int("generator_n_layers_hidden", 2, 8),
            "generator_n_units_hidden": trial.suggest_categorical("generator_n_units_hidden", [64, 128, 256]),
            "generator_nonlin": trial.suggest_categorical("generator_nonlin", ["elu", "relu", "selu", "leaky_relu"]),
            "generator_dropout": trial.suggest_categorical("generator_dropout", [0, 0.10, 0.25]),
            "discriminator_n_layers_hidden": trial.suggest_int("discriminator_n_layers_hidden", 2, 8),
            "discriminator_n_units_hidden": trial.suggest_categorical("discriminator_n_units_hidden", [64, 128, 256]),
            "discriminator_nonlin": trial.suggest_categorical("discriminator_nonlin", ["elu", "relu", "selu", "leaky_relu"]),
            "discriminator_dropout": trial.suggest_categorical("discriminator_dropout", [0, 0.10, 0.25]),
            "n_iter": trial.suggest_categorical("n_iter", [10, 15, 25, 50]),
            "lr": trial.suggest_categorical("lr", [1e-5, 1e-4, 1e-3, 1e-2]),
            "weight_decay": trial.suggest_float("weight_decay", 1e-5, 1e-2),
            "batch_size": trial.suggest_categorical("batch_size", [128, 256, 512]),
            "clipping_value": trial.suggest_categorical("clipping_value", [-1, 0, 1]),
            "encoder_max_clusters": trial.suggest_int("encoder_max_clusters", 1, 50),
            "adjust_inference_sampling": trial.suggest_categorical("adjust_inference_sampling", [True, False])
        }

        gen.synthcity_params = params
        gen.train()
        gen.gen(no_obsvs=len(gen.enc_real), no_synths=1)

        metric = self.eval_function(gen)
        trial.set_user_attr(self.eval_function.__name__, metric)

        return metric
