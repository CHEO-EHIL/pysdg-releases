import logging
from functools import partial
from datetime import datetime

import pandas as pd
import numpy as np
from scipy.stats import skew, norm
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_auc_score, accuracy_score

logger = logging.getLogger(__name__)

############################################
# NUMERICAL MAPPING FUNCTIONS TO NORMAL DISTRIBUTION
############################################
def map_numerical_to_normal(numerical_data, epsilon=1e-10):
    sorted_data = np.sort(numerical_data)
    ecdf = np.linspace(0, 1, len(sorted_data), endpoint=False) + (0.5 / len(sorted_data))
    ecdf = np.clip(ecdf, epsilon, 1 - epsilon)
    normal_values = norm.ppf(ecdf)
    return {"sorted_data": sorted_data, "normal_values": normal_values}


def sample_normal_based_on_numerical_data(normal_vals, mapping):
    sorted_data = mapping["sorted_data"]
    normal_values = mapping["normal_values"]
    return np.interp(normal_vals, normal_values, sorted_data)


def decode_numerical_from_normal(normal_values, mapping):
    sorted_data = mapping["sorted_data"]
    ecdf = norm.cdf(normal_values)
    return np.interp(ecdf, np.linspace(0, 1, len(sorted_data), endpoint=False), sorted_data)


def transform_numerical_to_normal(numerical_data, epsilon=1e-10):
    mapping = map_numerical_to_normal(numerical_data, epsilon)

    valid_mask = ~np.isnan(mapping["sorted_data"])  # Mask to remove NaNs
    sorted_data_clean = mapping["sorted_data"][valid_mask]
    normal_values_clean = mapping["normal_values"][valid_mask]

    # Ensure uniqueness by taking the first occurrence of each unique value
    data_to_normal = pd.Series(normal_values_clean, index=sorted_data_clean).groupby(level=0).first()

    transformed_data = pd.Series(numerical_data).map(data_to_normal)
    transformed_data = transformed_data.fillna(transformed_data.mean(skipna=True))
    if transformed_data.isnull().any():
        raise ValueError("Mapping failed: input data contains values not in sorted_data.")

    return transformed_data

############################################
# CATEGORICAL MAPPING FUNCTIONS TO NORMAL DISTRIBUTION
############################################
def map_categorical_to_intervals(categorical_data, epsilon=1e-10):
    categories, counts = np.unique(categorical_data, return_counts=True)
    proportions = counts / len(categorical_data)
    cumulative_proportions = np.cumsum(proportions)
    cumulative_proportions = np.clip(cumulative_proportions, epsilon, 1 - epsilon)
    interval_boundaries = norm.ppf(cumulative_proportions)

    return {
        "categories": categories,
        "proportions": proportions,
        "interval_boundaries": interval_boundaries,
    }


def sample_normal_based_on_proportions(normal_vals, mapping):
    categories = mapping["categories"]
    interval_boundaries = mapping["interval_boundaries"]

    # Extend boundaries to include -∞ and +∞
    extended_boundaries = np.concatenate([[-np.inf], interval_boundaries])

    sampled_categories = np.empty(len(normal_vals), dtype=categories.dtype)
    for i, sample in enumerate(normal_vals):
        # Find the appropriate interval for the sample
        for j in range(len(extended_boundaries) - 1):
            if extended_boundaries[j] <= sample < extended_boundaries[j + 1]:
                sampled_categories[i] = categories[j]
                break

    return sampled_categories

def decode_categorica_from_intervals(normal_values, mapping, epsilon=1e-10):
    categories = mapping["categories"]
    interval_boundaries = mapping["interval_boundaries"]

    cumulative_proportions = norm.cdf(normal_values)
    cumulative_proportions = np.clip(cumulative_proportions, epsilon, 1 - epsilon)

    decoded_categories = np.searchsorted(interval_boundaries, cumulative_proportions)
    decoded_categories = categories[decoded_categories]

    return decoded_categories

def transform_categorical_to_normal(categorical_data, epsilon=1e-10):
    mapping = map_categorical_to_intervals(categorical_data, epsilon)
    categories = mapping["categories"]
    interval_boundaries = mapping["interval_boundaries"]

    # Add a lower boundary (-inf) for the first category
    interval_boundaries = np.insert(interval_boundaries, 0, -np.inf)

    category_to_bounds = {
        category: (interval_boundaries[i], interval_boundaries[i + 1])
        for i, category in enumerate(categories)
    }

    def sample_from_interval(category):
        # If category is not in the mapping, use the first valid category's bounds
        if category not in category_to_bounds:
            category = categories[0]
        lower_bound, upper_bound = category_to_bounds[category]
        midpoint = (lower_bound + upper_bound) / 2
        scale = max((upper_bound - lower_bound) / 6, epsilon)  # Scale avoids zero
        return norm.rvs(loc=midpoint, scale=scale, random_state=123) # Random state for reproducibility

    normal_data = categorical_data.map(sample_from_interval)
    normal_data = pd.Series(normal_data.astype(float))
    normal_data.replace([np.inf, -np.inf], np.nan, inplace=True)

    if normal_data.isna().all():
        normal_data.fillna(0, inplace=True)
    else:
        normal_data.fillna(normal_data.mean(skipna=True), inplace=True)

    return normal_data

############################################
# DATA PREPROCESSING UTILS
############################################

def transform_df_to_mvn(df: pd.DataFrame):
    """
    Transform a dataframe to a multivariate normal distribution.
    Assumes that the only dtypes are category or number.
    """
    df_out = {}

    cat_cols_idx = [df.columns.get_loc(col) for col
                    in df.select_dtypes(include=["category"]).columns]
    num_cols_idx = [df.columns.get_loc(col) for col in
                    df.select_dtypes(include=["number"]).columns]
    datetime_cols_idx = [df.columns.get_loc(col) for col in
                         df.select_dtypes(include=["datetime64", "datetime", "datetimetz"]).columns]

    for i, col in enumerate(df.columns):
        if i in cat_cols_idx:
            df_out[col] = transform_categorical_to_normal(df[col])
        elif i in num_cols_idx:
            df_out[col] = transform_numerical_to_normal(df[col])
        elif i in datetime_cols_idx:
            df_out[col] = df[col].map(datetime_to_days_since_1990)
            df_out[col] = transform_numerical_to_normal(df_out[col])

    return pd.DataFrame(df_out)


def encode_categorical_df_pair(df1: pd.DataFrame, df2: pd.DataFrame):
    """
    Encode categorical columns in two dataframes consistently in respect to each other.
    """
    le = LabelEncoder()
    encoded = pd.concat([df1, df2], keys=["df1", "df2"])
    for col in encoded.select_dtypes(include=["category"]).columns:
        encoded[col] = le.fit_transform(encoded[col])
        encoded[col] = encoded[col].astype('category')


    return encoded.loc["df1"], encoded.loc["df2"]


def scale_numerical_df_pair(df1: pd.DataFrame, df2: pd.DataFrame):
    """
    Scale numerical columns in two dataframes consistently in respect to each other.
    """
    combined = pd.concat([df1, df2], keys=["df1", "df2"])
    for col in combined.select_dtypes(include=[np.number]).columns:
        min_val = combined[col].min()
        max_val = combined[col].max()
        range_val = max_val - min_val

        if range_val == 0:
            logger.warning(
                f"Numerical column {col} has all elements equal and will be scaled to 1.0 to avoid division by zero."
            )
            range_val = 1

        combined[col] = (combined[col] - min_val) / range_val

    return combined.loc["df1"], combined.loc["df2"]


def convert_num_to_cat_pair(df1, df2):

    combined = pd.concat([df1, df2], keys=["df1", "df2"])

    # interestingly, the line below appears to change the type
    # a categorical col to that of object if the
    # the target cols of df1 and df2 have different
    # categories. So you need to change the type back
    #TODO: find an alternative way
    for col in combined.select_dtypes(include=["object"]):
        combined[col] = combined[col].astype("category")

    for col in combined.select_dtypes(include=[np.number]).columns:
        min_val = combined[col].min()
        max_val = combined[col].max()
        range_val = max_val - min_val

        if range_val == 0:
            logger.warning(
                f"Numerical column {col} has all elements equal and will be scaled to 1.0 to avoid division by zero."
            )
            range_val = 1

        combined[col] = (combined[col] - min_val) / range_val

    for col in combined.select_dtypes(include=[np.number]).columns:
        combined[col].fillna(combined[col].mean(), inplace=True)
        combined[col] = optimal_binning(combined[col])
        combined[col] = combined[col].astype("category")

    return combined.loc["df1"], combined.loc["df2"]

def preprocess_df_pair(df1: pd.DataFrame, df2: pd.DataFrame):
    """
    Preprocess two dataframes consistently in respect to each other.
    """
    df1, df2 = convert_num_to_cat_pair(df1, df2)
    df1, df2 = encode_categorical_df_pair(df1, df2)
    # df1, df2 = scale_numerical_df_pair(df1, df2)
    return df1, df2

############################################
# OTHER UTILS
############################################
def datetime_to_days_since_1990(dt):

    if isinstance(dt, str):
        dt = pd.to_datetime(dt)
    elif isinstance(dt, datetime):
        dt = pd.Timestamp(dt)
    elif isinstance(dt, pd.Timestamp):
        pass
    elif isinstance(dt, np.datetime64):
        dt = pd.Timestamp(dt)
    else:
        raise ValueError("Input must be a string, datetime object, pandas Timestamp, or numpy.datetime64")

    reference_datetime = pd.Timestamp("1990-01-01")
    time_difference = dt - reference_datetime
    return float(time_difference.days)


def optimal_binning(data):
    data = np.array(data)

    if np.all(data == data[0]):
        return 2

    n = len(data)
    if n < 2:
        raise ValueError("Data must have at least 2 elements.")

    data_range = np.max(data) - np.min(data)
    if data_range == 0:
        return 2

    sigma = np.std(data, ddof=1)
    iqr = np.percentile(data, 75) - np.percentile(data, 25)
    g1 = skew(data)

    scott_bins = int((data_range / (3.5 * sigma / (n ** (1/3)))) if sigma > 0 else 10)
    freedman_bins = int((data_range / (2 * iqr / (n ** (1/3)))) if iqr > 0 else 10)
    sturges_bins = int(np.log2(n) + 1)
    doanes_bins = int(1 + np.log2(n) + np.log2(1 + abs(g1) / np.sqrt((6 * (n - 2)) / ((n + 1) * (n + 3)))))

    if abs(g1) > 1:  # Highly skewed data
        chosen_bins = max(freedman_bins, doanes_bins)
    else:  # Normal or slightly skewed data
        chosen_bins = max(scott_bins, sturges_bins)

    # Cap bins to avoid over-partitioning
    chosen_bins = max(2, chosen_bins)
    chosen_bins = min(chosen_bins, int(np.sqrt(n)))

    return chosen_bins


def check_df_types(df: pd.DataFrame):
    valid_types = [np.number, 'category',
                   'datetime64[ns]', 'datetime',
                   'datetimetz', 'datetime64']
    invalid_cols = df.select_dtypes(exclude=valid_types)
    if len (invalid_cols.columns) != 0:
        invalid_columns_info = [(col, df[col].dtype) for col in invalid_cols.columns]
        raise ValueError(f"""
                         Passed dataframe must only contain columns of type {valid_types}.
                         Columns {invalid_columns_info} are of invalid type.
                         """)


def align_y_pred(y_pred, y_pred_classes, all_classes):
    """
    Aligns y_pred probabilities with the full set of classes in all_classes.

    Parameters:
    - y_pred: list or numpy array of predicted probabilities.
    - y_pred_classes: list of predicted class labels corresponding to y_pred probabilities.
    - all_classes: list of all possible class labels (both from y_pred and y_true).
    """
    aligned_y_pred = np.zeros(len(all_classes))
    class_to_index = {cls_: i for i, cls_ in enumerate(all_classes)}

    for prob, cls_ in zip(y_pred, y_pred_classes):
        if cls_ in class_to_index:
            aligned_y_pred[class_to_index[cls_]] = prob

    return aligned_y_pred


def coerce_bool_cols_to_cat(df: pd.DataFrame):
    for col in df.select_dtypes(include='bool').columns:
        df[col] = df[col].astype('category')
    return df

#TODO: refactor
def calc_mixed_auroc(y_true,
                     y_pred_matrix,
                     y_pred_classes,
                     strategy="ovr"):
    
    y_true = y_true.values

    # single label
    if len(set(y_true)) == 1 and len(y_pred_classes) == 1:
        if y_true[0] == list(y_pred_classes)[0]:
            return 1.0
        return 0
    # binary classificaiton
    elif (len(set(y_true)) == 2 and len(y_pred_classes) == 2):
        y_pred_matrix = y_pred_matrix[:, 1]
        return roc_auc_score(y_true, y_pred_matrix)
    # single class in y_true and > 1 in y_pred
    elif (len(set(y_true))) == 1 and len(y_pred_classes) > 1:
        if set(y_true).intersection(y_pred_classes):
            y_pred_matrix = np.argmax(y_pred_matrix, axis=1)
            return accuracy_score(y_true, y_pred_matrix)
        else:
            return 0
    # other cases, incl. mismatching classes
    else:
        all_classes = y_true.dtype.categories.values
        y_pred_matrix = np.array([
            align_y_pred(i, y_pred_classes, all_classes)
            for i in y_pred_matrix
        ])

        y_pred_matrix = y_pred_matrix[:, list(set(y_true))]

        def generate_random_row(size):
            row = np.random.rand(size)
            return row / row.sum()

        bad_indices = [idx for idx,
                    row in enumerate(y_pred_matrix) if row.sum() != 1]
        for idx in bad_indices:
            y_pred_matrix[idx] = generate_random_row(y_pred_matrix.shape[1])

        y_pred_matrix = y_pred_matrix/y_pred_matrix.sum(axis=1, keepdims=True)

        if y_pred_matrix.shape[1] == 2:
            y_pred_matrix = np.argmax(y_pred_matrix, axis=1)
            return roc_auc_score(y_true, y_pred_matrix)

        auroc = roc_auc_score(y_true,
                            y_pred_matrix,
                            multi_class=strategy,
                            )
        return auroc