import pandas as pd
import numpy as np

from pysdg.synth.metrics import calc_multivar_hellinger_distance
from pysdg.synth.utils import coerce_bool_cols_to_cat
from pysdg.privacy.mmbrshp import calc_membership_risk
from pysdg.privacy.inference_risk import calc_inference_risk


def calc_vulnerability_utility(df_train: pd.DataFrame,
                               df_holdout: pd.DataFrame,
                               df_synthetic: pd.DataFrame,
                               quasi_identifiers: list) -> float:
    """Calculate the vulnerability utility (VU) score.

    Args:
        df_train (pd.DataFrame): The training dataset.
        df_holdout (pd.DataFrame): The holdout dataset.
        df_synthetic (pd.DataFrame): The synthetic dataset.
        quasi_identifiers (list): List of quasi-identifiers.

    Returns:
        float: The vulnerability utility score.

    Raises:
        ValueError: If the columns of train and synthetic dataframes don't match.
        ValueError: If the columns of train and holdout dataframes don't match.
    """
    #TODO: it's a good idea to have some data validating routine eventually
    if np.all(df_train.columns != df_synthetic.columns):
        raise ValueError("Columns of train and synthetic dataframes don't match.")

    if np.all(df_train.columns != df_holdout.columns):
        raise ValueError("Columns of train and holdout dataframes don't match.")

    df_train = coerce_bool_cols_to_cat(df_train)
    df_synthetic = coerce_bool_cols_to_cat(df_synthetic)
    df_holdout = df_holdout.astype(df_train.dtypes.to_dict())

    U = calc_multivar_hellinger_distance(df_train,
                                         df_synthetic,
                                         encoded=False)

    theta_1 = calc_membership_risk(df_synthetic,
                                   df_train,
                                   df_holdout,
                                   population_size=10*len(df_train),
                                   attack_size=int(0.2*len(df_train)),
                                   hamming_threshold=3,
                                   quasi_vars=quasi_identifiers,
                                   )
    theta_1 = theta_1['f1']
    theta_2 = calc_inference_risk(
        df_train=df_train,
        df_holdout=df_holdout,
        df_synthetic=df_synthetic,
        quasi_identifiers=quasi_identifiers,
    )

    tau_1 = 0.20
    tau_2 = 0.15
    term_11 = (theta_1 <= tau_1)
    term_12 = (theta_1 > tau_1)
    term_21 = (theta_2 <= tau_2)
    term_22 = (theta_2 > tau_2)

    term_1 = int((term_11 and term_21))
    term_2 = int((term_12 and term_22))
    term_3 = int((term_12 and term_21))
    term_4 = int((term_11 and term_22))

    term_exp_1 = 1/(1 + np.exp(5*(tau_1 - theta_1)))
    term_exp_2 = 1/(1 + np.exp(5*(tau_2 - theta_2)))

    vu = (
        (term_1 * ((1 - U)/2 + 0.5)) +
        (term_2 * (term_exp_1 + term_exp_2)/2) +
        (term_3 * (term_exp_1 + 0.5)/2) +
        (term_4 * (term_exp_2 + 0.5)/2)
    )
    return vu
