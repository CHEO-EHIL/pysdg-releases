import pandas as pd
import numpy as np
from collections import defaultdict

from sklearn.neighbors import KNeighborsClassifier

from pysdg.synth.utils import (
    preprocess_df_pair,
    calc_mixed_auroc
    )

#TODO: refactor
def calc_inference_risk(df_train: pd.DataFrame,
                        df_holdout: pd.DataFrame,
                        df_synthetic: pd.DataFrame,
                        quasi_identifiers: list | None = None,
                        knn_neighbours: int = 5,
                        auroc_multiclass_mode: str = "ovr",
                        ):
    """Calculate the inference risk score for a synthetic dataset.

    Args:
        df_train (pd.DataFrame): The original dataframe.
        df_holdout (pd.DataFrame): The holdout dataframe.
        df_synthetic (pd.DataFrame): The synthetic dataframe.
        quasi_identifiers (list): List of quasi-identifiers.
        knn_neighbours (int): Number of neighbors for the KNN classifier.
        auroc_multiclass_mode (str): Strategy for calculating AUROC for multiclass classification.

    Returns:
        float: The vulnerability utility score.

    Raises:
        ValueError: If columns of original and synthetic dataframes don't match.
        ValueError: If columns of original and holdout dataframes don't match.
        ValueError: If quasi-identifiers are not a list.
        ValueError: If quasi-identifiers are empty.
    """

    if not isinstance(quasi_identifiers, list) or len(quasi_identifiers) == 0:
        raise ValueError("Quasi-identifiers must be a non-empty list of column names.")

    if auroc_multiclass_mode not in ["ovo", "ovr"]:
        raise ValueError("AUROC multiclass mode must be either 'ovo' or 'ovr'.")

    sensitive_attributes = [col for col in df_train.columns if col not in quasi_identifiers]
    cols = quasi_identifiers + sensitive_attributes
    df_qi_syn_ref = df_synthetic[cols]
    metrics = defaultdict(dict)

    #
    # get disclosure risks for the originaling set
    #
    df_qi_train = df_train[cols]
    df_qi_syn = df_qi_syn_ref.copy()
    df_qi_syn, df_qi_train = preprocess_df_pair(df_qi_syn, df_qi_train)

    for attr in sensitive_attributes:
        try:
            X = df_qi_syn[quasi_identifiers]
            y = df_qi_syn[attr]
            y_pred_possible_classes = set(y)
            
            attack_model = KNeighborsClassifier(n_neighbors=knn_neighbours, n_jobs=-1)
            attack_model.fit(X, y)
            preds = attack_model.predict_proba(df_qi_train[quasi_identifiers])
            auc = calc_mixed_auroc(df_qi_train[attr],
                                y_pred_matrix=preds,
                                y_pred_classes=y_pred_possible_classes,
                                strategy=auroc_multiclass_mode
                                )
            metrics[attr]["auroc_member"] = auc

        except Exception as e:
            raise ValueError(f"failed to process col {attr} in train-syn pair: {e}")

    #
    # get disclosure risks for the holdout set
    #
    df_qi_holdout = df_holdout[cols]
    df_qi_syn = df_qi_syn_ref.copy()
    df_qi_syn, df_qi_holdout = preprocess_df_pair(df_qi_syn, df_qi_holdout)

    for attr in sensitive_attributes:
        try:
            X = df_qi_syn[quasi_identifiers]
            y = df_qi_syn[attr]
            y_pred_possible_classes = set(y)


            attack_model = KNeighborsClassifier(n_neighbors=knn_neighbours, n_jobs=-1)
            attack_model.fit(X, y)
            preds = attack_model.predict_proba(df_qi_holdout[quasi_identifiers])
            auc = calc_mixed_auroc(df_qi_holdout[attr],
                                   y_pred_matrix=preds,
                                   y_pred_classes=y_pred_possible_classes,
                                   strategy=auroc_multiclass_mode
                                   )
            metrics[attr]["auroc_non_member"] = auc

        except Exception as e:
            raise ValueError(f"failed to process col {attr} in holdout-syn pair: {e}")

    # A_rel = A_member - A_non_member
    for attr in sensitive_attributes:
        metrics[attr]["auroc_rel"] = metrics[attr]["auroc_member"] - metrics[attr]["auroc_non_member"]

    out = np.max(
        [metrics[i]["auroc_rel"] for i in metrics.keys() if metrics[i]["auroc_member"] >= 0.6]
        )
    if not out:
        out = np.max(
            [metrics[i]["auroc_rel"] for i in metrics.keys()]
            )
    return out